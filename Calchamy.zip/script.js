const consolebox = document.getElementById('consolebox')
consolebox.style.display = 'none'
const numbox = document.getElementById('numbox')
const opbox = document.getElementById('opbox')
const target = document.getElementById('target')
const levelbox = document.getElementById('levelbox')
const movesbox=document.getElementById('moves')
/// format: [given numbers, target, least possible moves, available operators]
var levels = [
	[[1], 2, 1, ['+']],
	[[1], 5, 3, ['+']],
	[[2], 50, 6, ['+']],
	[[1], 0, 1, ['-']],
	[[7, 5], 3, 2, ['-', '+']],
	[[5, 8], 7, 3, ['-', '+']],
	[[2], 16, 2, ['x']],
	[[3], 30, 3, ['+', '-', 'x']],
	[[1], 13, 5, ['+', '-', 'x']],
	[[1000, 5], 50, 4, ['+', '-', 'x', '/']],
	[[1, 4], 18,3,['/','+','-','*']],
    [[5,2],122,5,['+','-','*','/']],
	[[3], 111, 5, ['+','-','*','/']],
	[[11, 9], 3, 2, ['+','-','*','/','root']],
	[[3,2], 1296, 3, ['*','^']],
	[[1], 100000, 5, ['+','-','x','/','root','^']],
	[]
]
let mode = '';
let level = 0;
let terms = []
let move_count = 0
let random = 0;
  function validate(value) {
	if (terms[0] && typeof terms[terms.length - 1] == typeof value) {
		return false
	}
	if (!terms[0] && typeof value == 'string') {
		return false
	}
	return true
}
function startPlay(playMode) {
	document.getElementById("levelbtn").style.display = 'none'
	document.getElementById("zenbtn").style.display = 'none'
	document.getElementById("logo").style.display = 'none'
	document.getElementById('consolebox').style.display = 'initial'
	mode = playMode;
	if (mode == 'zen') {
		level = 16
	}
	nextLevel()
}//if zenMode is on, then generate random levels array and use that

function calculate(){
	let expression = consolebox.innerText;
	expression = expression.replace('^', '**').replace('x', '*').replace('--','+')
	if (expression.includes('root')){
		return parseInt(expression[expression.length - 1]) ** (1/parseInt(expression[0]))
	}
    return eval(expression);
  
}
function add(value) {
  	random = getRandomInt(5)
	eval(`(new Audio('Audios/buttonpress${random}.mp3')).play()`)
    //playing sounds when a numBox is clicked
  	//terms is empty array
	let allowed = validate(value);
	if (!allowed) return;
	terms.push(value);
	consolebox.innerText += value
	if (terms.length == 3) {
		move_count += 1
		movesbox.innerText = "moves: " + move_count
		res = calculate()
		consolebox.innerHTML = ''
		terms = []
  		//index in levels array is the level
  		// the actual object (another array) first # is given # second is target #
  		if (res == levels[level][1]) {
        	
			if (mode == 'level') {
        
				movesbox.innerText += `, ${move_count - levels[level][2]} moves more than minimum`
			}
			setTimeout(() => {
				movesbox.innerText = ''
			}, 2000)
			move_count = 0
       
      		level += 1;
      if (level == 16) {
		levelbox.innerText = 'Game Complete!'
		setTimeout(() => {
			window.location.reload()
		}, 2000)
	}
        	nextLevel();
  		} else {
			if ((res != 0) && (res == Math.floor(res)) && (!document.getElementById(res))) {
	  			numbox.innerHTML += `<button class="block" id="${res}" onclick="add(${res})">${res}</button>`;
			}
  		}
	}
}

function nextLevel() {
	if (mode == 'zen') {
		let givens = [getRandomInt(9), getRandomInt(9)]
		let its = getRandomInt(3) + 2
		let ops = ['+','-','*','/','root','^']
		let randop = ops[getRandomInt(6)-1]
		let expterms = [givens[0],randop,givens[1]]
		let expression = expterms.join('')
		if (expression.includes("root")) {
			expression = expterms[expterms.length - 1] ** (1/expterms[0])
		} else {
			expression = eval(expression)
		}
		for (i=0;i<its;i++) {
			let randop = ops[Math.floor(Math.random(6))]
			let expterms = [0,randop,getRandomInt(10000)]
			expression = expterms.join('')
			if (expression.includes("root")) {
				expression = expterms[expterms.length - 1] ** (1/expterms[0])
			} else {
				expression = eval(expression)
			}
			if (!givens.includes(expression)) {
				givens.push(expression)
			}
		}
		givens.splice(givens.indexOf(expression), 1)
		let presets = [givens,expression,its,ops]
		levels[levels.length - 1] = presets
		numbox.innerHTML = '';
		for (var i=0; i<presets[0].length; i++)  {
			numbox.innerHTML +=`<button class="block" id="${presets[0][i]}" onclick="add(${presets[0][i]})">${presets[0][i]}</button>`;
  		}
		opbox.innerHTML = '';
   		target.innerText=expression;
   		levelbox.innerText='';
		for (var i=0; i<presets[3].length; i++) {
			opbox.innerHTML += `<button class="block" onclick="add('${presets[3][i]}')">${presets[3][i]}</button>`;
  		}
	} else {
		presets = levels[level]
		numbox.innerHTML = '';
		for (var i=0; i<presets[0].length; i++)  {
			numbox.innerHTML +=`<button class="block" id="${presets[0][i]}" onclick="add(${presets[0][i]})">${presets[0][i]}</button>`;
		}
		opbox.innerHTML = '';
   		target.innerText='';
   		levelbox.innerText='';
		for (var i=0; i<presets[3].length; i++) {
			opbox.innerHTML += `<button class="block" onclick="add('${presets[3][i]}')">${presets[3][i]}</button>`;
  		}
   		levelbox.innerText = "level " + (level+1);
   		target.innerText = "target: " + presets[1];
		move_count = 0;
	}
}

function getRandomInt(max) {
	return Math.floor(Math.random() * max)+1;
}